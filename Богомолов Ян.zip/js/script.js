$(document).ready(function(){
    $('.bxslider').bxSlider({
        pager: false,
        // captions: true,
        auto: true,
    })
});

$(document).ready(function(){
    $('.bxslider_team').bxSlider({
        //pager: false,
        // captions: true,
        auto: true,
        controls:false,
    })
});